# The Backend Server

This is stage in Developement.

Run Command Prompt or Terminal in director of project.

1. `npm install` or `yarn install`

2. Install XAMPP and Start Apache and MySQL for database in XAMPP Control Panel.

3. Create the database(`db_scope`) for server in XAMPP Apache server[http://localhost/phpmyadmin/].

4. `npm start` or `yarn start`

5. Add the Service Provider in service-providers table.

6. The server is running on [http://localhost:5000]

7. We get the url(https) for server from ngrok[https://dashboard.ngrok.com].

8. Final, we use this url for server.
   ex: `https://singularly-hot-cod.ngrok-free.app`
